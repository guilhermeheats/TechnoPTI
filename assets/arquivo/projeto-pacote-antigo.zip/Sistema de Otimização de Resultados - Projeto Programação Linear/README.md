# Sistema de Otimização de Resultados - Projeto Programação Linear
Projeto final para a disciplina de Programação Linear e Aplicações.
