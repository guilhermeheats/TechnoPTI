from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# Configuração do Banco de Dados
db = create_engine('sqlite:///db.sqlite3')
Session = sessionmaker(bind=db)
session = Session()

Base = declarative_base()