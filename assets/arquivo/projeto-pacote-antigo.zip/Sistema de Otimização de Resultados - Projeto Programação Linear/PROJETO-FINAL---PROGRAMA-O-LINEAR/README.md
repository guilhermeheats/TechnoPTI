# 🧮 Sistema de Resolução Simplex (PL) - Technopiti 
Projeto desenvolvido para a disciplina de Pesquisa Operacional/Programação Linear.

## 🏗️ Arquitetura
* **Frontend:** React + Vite
* **Backend:** Python + Flask + PuLP
* **Banco de Dados:** SQLite
* **Documentação:** MkDocs

## 🚀 Como rodar o projeto Localmente

### 1. Clonando o projeto localmente
```bash
git clone https://github.com/usuario_exemplo/sistema-simplex-ads.git
cd sistema-simplex-ads
```

### 2. Rodando o Backend (Python)
```bash
cd backend
python -m venv venv
#No Linux/Mac: source venv/bin/activate
#No Windows: .\venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
### 3. Rodando o Frontend (React)
```bash
cd frontend
npm install
npm run dev
```
---